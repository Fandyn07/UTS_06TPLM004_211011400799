package com.example.fandy_uts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
